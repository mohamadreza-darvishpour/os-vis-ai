from django.contrib import admin
from . import models
# Register your models here.



admin.site.register( models.product  )
admin.site.register( models.shop  )
admin.site.register( models.home_pages  )
admin.site.register( models.feature_table  )
admin.site.register( models.messages  )
